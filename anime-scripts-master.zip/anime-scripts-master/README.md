# anime-scripts
Shell scripts about anime
